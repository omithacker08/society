-- Complete Database Schema
-- Generated from actual database

CREATE TABLE apartment_master (
  id INTEGER NOT NULL DEFAULT nextval('apartment_master_id_seq'::regclass),
  society_id INTEGER,
  wing_id INTEGER,
  apartment_number VARCHAR(10) NOT NULL,
  floor_number INTEGER,
  carpet_area DECIMAL(10,2) DEFAULT 1000,
  built_up_area DECIMAL(10,2),
  property_type VARCHAR(20) DEFAULT 'residential'::character varying,
  bhk_type VARCHAR(10),
  has_balcony BOOLEAN DEFAULT false,
  is_occupied BOOLEAN DEFAULT false,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE apartment_requests (
  id INTEGER NOT NULL DEFAULT nextval('apartment_requests_id_seq'::regclass),
  user_id INTEGER,
  society_id INTEGER,
  wing_id INTEGER,
  apartment_number VARCHAR(10) NOT NULL,
  ownership_type VARCHAR(20) DEFAULT 'owner'::character varying,
  status VARCHAR(20) DEFAULT 'pending'::character varying,
  admin_comments TEXT,
  approved_by INTEGER,
  approved_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE audit_logs (
  id INTEGER NOT NULL DEFAULT nextval('audit_logs_id_seq'::regclass),
  user_id INTEGER,
  entity_type VARCHAR(50) NOT NULL,
  entity_id INTEGER,
  action VARCHAR(100) NOT NULL,
  details JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE budget_allocations (
  id INTEGER NOT NULL DEFAULT nextval('budget_allocations_id_seq'::regclass),
  society_id INTEGER,
  category VARCHAR(100) NOT NULL,
  allocated_amount DECIMAL(12,2) NOT NULL,
  spent_amount DECIMAL(12,2) DEFAULT 0,
  financial_year VARCHAR(10),
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE builder_apartment_sales (
  id INTEGER NOT NULL DEFAULT nextval('builder_apartment_sales_id_seq'::regclass),
  apartment_master_id INTEGER,
  society_id INTEGER,
  status VARCHAR(20) DEFAULT 'available'::character varying,
  sale_amount DECIMAL(12,2),
  booking_amount DECIMAL(12,2),
  sale_date DATE,
  booking_date DATE,
  buyer_name VARCHAR(255),
  buyer_contact VARCHAR(20),
  buyer_email VARCHAR(255),
  notes TEXT,
  created_by INTEGER,
  updated_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE builder_expenses (
  id INTEGER NOT NULL DEFAULT nextval('builder_expenses_id_seq'::regclass),
  project_id INTEGER,
  category VARCHAR(100) NOT NULL,
  description TEXT NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  expense_date DATE NOT NULL,
  vendor_name VARCHAR(255),
  invoice_number VARCHAR(100),
  payment_status VARCHAR(20) DEFAULT 'pending'::character varying,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE builder_projects (
  id INTEGER NOT NULL DEFAULT nextval('builder_projects_id_seq'::regclass),
  society_id INTEGER,
  project_name VARCHAR(255) NOT NULL,
  total_budget DECIMAL(15,2) NOT NULL,
  total_expenses DECIMAL(15,2) DEFAULT 0,
  expected_revenue DECIMAL(15,2) DEFAULT 0,
  actual_revenue DECIMAL(15,2) DEFAULT 0,
  start_date DATE,
  expected_completion_date DATE,
  status VARCHAR(20) DEFAULT 'active'::character varying,
  created_by INTEGER,
  updated_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE builder_revenues (
  id INTEGER NOT NULL DEFAULT nextval('builder_revenues_id_seq'::regclass),
  project_id INTEGER,
  apartment_sale_id INTEGER,
  revenue_type VARCHAR(20),
  amount DECIMAL(12,2) NOT NULL,
  received_date DATE NOT NULL,
  payment_method VARCHAR(50),
  transaction_reference VARCHAR(100),
  notes TEXT,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE chat_messages (
  id INTEGER NOT NULL DEFAULT nextval('chat_messages_id_seq'::regclass),
  chat_id INTEGER,
  sender_id INTEGER,
  message TEXT NOT NULL,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE chats (
  id INTEGER NOT NULL DEFAULT nextval('chats_id_seq'::regclass),
  participant1_id INTEGER,
  participant2_id INTEGER,
  society_id INTEGER,
  last_message_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE entry_passes (
  id INTEGER NOT NULL DEFAULT nextval('entry_passes_id_seq'::regclass),
  user_id INTEGER,
  visitor_name VARCHAR(255) NOT NULL,
  visitor_phone VARCHAR(20),
  purpose TEXT,
  valid_from TIMESTAMP NOT NULL,
  valid_until TIMESTAMP NOT NULL,
  pass_type VARCHAR(20) DEFAULT 'entry'::character varying,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE facilities (
  id INTEGER NOT NULL DEFAULT nextval('facilities_id_seq'::regclass),
  society_id INTEGER,
  name VARCHAR(255) NOT NULL,
  facility_type VARCHAR(50) NOT NULL,
  max_booking_hours INTEGER DEFAULT 1,
  operational_start TIME DEFAULT '06:00:00'::time without time zone,
  operational_end TIME DEFAULT '22:00:00'::time without time zone,
  is_available BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE facility_bookings (
  id INTEGER NOT NULL DEFAULT nextval('facility_bookings_id_seq'::regclass),
  facility_id INTEGER,
  user_id INTEGER,
  booking_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  status VARCHAR(20) DEFAULT 'confirmed'::character varying,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE family_members (
  id INTEGER NOT NULL DEFAULT nextval('family_members_id_seq'::regclass),
  apartment_id INTEGER,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  phone VARCHAR(20),
  relationship VARCHAR(50),
  age INTEGER,
  gender VARCHAR(10),
  occupation VARCHAR(100),
  status VARCHAR(20) DEFAULT 'pending'::character varying,
  admin_comments TEXT,
  approved_by INTEGER,
  approved_at TIMESTAMP,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE fund_transactions (
  id INTEGER NOT NULL DEFAULT nextval('fund_transactions_id_seq'::regclass),
  society_id INTEGER,
  transaction_type VARCHAR(20),
  amount DECIMAL(12,2) NOT NULL,
  description TEXT,
  reference_type VARCHAR(50),
  reference_id INTEGER,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE invoices (
  id INTEGER NOT NULL DEFAULT nextval('invoices_id_seq'::regclass),
  purchase_order_id INTEGER,
  invoice_number VARCHAR(50) NOT NULL,
  invoice_date DATE NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  tax_amount DECIMAL(12,2) DEFAULT 0,
  total_amount DECIMAL(12,2) NOT NULL,
  payment_status VARCHAR(20) DEFAULT 'pending'::character varying,
  payment_date DATE,
  invoice_file VARCHAR(500),
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE item_masters (
  id INTEGER NOT NULL DEFAULT nextval('item_masters_id_seq'::regclass),
  society_id INTEGER,
  name VARCHAR(255) NOT NULL,
  category VARCHAR(100),
  unit VARCHAR(50),
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE maid_assignments (
  id INTEGER NOT NULL DEFAULT nextval('maid_assignments_id_seq'::regclass),
  maid_id INTEGER,
  user_id INTEGER,
  wing_id INTEGER,
  apartment_number VARCHAR(10),
  assigned_by INTEGER,
  status VARCHAR(20) DEFAULT 'pending'::character varying,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  apartment_master_id INTEGER
);

CREATE TABLE maid_attendance (
  id INTEGER NOT NULL DEFAULT nextval('maid_attendance_id_seq'::regclass),
  maid_id INTEGER,
  apartment_id INTEGER,
  entry_time TIMESTAMP,
  exit_time TIMESTAMP,
  marked_by INTEGER,
  exit_marked_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  apartment_master_id INTEGER
);

CREATE TABLE maid_reviews (
  id INTEGER NOT NULL DEFAULT nextval('maid_reviews_id_seq'::regclass),
  maid_id INTEGER,
  user_id INTEGER,
  rating INTEGER,
  review TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE maids (
  id INTEGER NOT NULL DEFAULT nextval('maids_id_seq'::regclass),
  society_id INTEGER,
  name VARCHAR(255) NOT NULL,
  services TEXT[] NOT NULL,
  phone VARCHAR(20),
  email VARCHAR(255),
  is_verified BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  user_id INTEGER,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE maintenance_bills (
  id INTEGER NOT NULL DEFAULT nextval('maintenance_bills_id_seq'::regclass),
  apartment_id INTEGER,
  society_id INTEGER,
  amount DECIMAL(10,2) NOT NULL,
  billing_month INTEGER NOT NULL,
  billing_year INTEGER NOT NULL,
  due_date DATE NOT NULL,
  status VARCHAR(20) DEFAULT 'pending'::character varying,
  payment_date DATE,
  payment_method VARCHAR(50),
  transaction_id VARCHAR(100),
  late_fee DECIMAL(10,2) DEFAULT 0,
  calculation_type VARCHAR(20),
  rate_used DECIMAL(10,2),
  area_used DECIMAL(10,2),
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  apartment_master_id INTEGER,
  approved_by INTEGER,
  approved_at TIMESTAMP,
  admin_notes TEXT
);

CREATE TABLE maintenance_config (
  id INTEGER NOT NULL DEFAULT nextval('maintenance_config_id_seq'::regclass),
  society_id INTEGER,
  calculation_type VARCHAR(20),
  frequency VARCHAR(20),
  fixed_amount DECIMAL(10,2),
  apartment_rate_per_sqft DECIMAL(10,2),
  commercial_rate_per_sqft DECIMAL(10,2),
  due_day INTEGER DEFAULT 31,
  late_fee_percentage DECIMAL(5,2) DEFAULT 5,
  grace_period_days INTEGER DEFAULT 5,
  is_active BOOLEAN DEFAULT true,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE maintenance_payments (
  id INTEGER NOT NULL DEFAULT nextval('maintenance_payments_id_seq'::regclass),
  user_id INTEGER,
  society_id INTEGER,
  amount DECIMAL(10,2) NOT NULL,
  payment_date DATE DEFAULT CURRENT_DATE,
  due_date DATE,
  status VARCHAR(20) DEFAULT 'pending'::character varying,
  payment_method VARCHAR(50),
  transaction_id VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE maintenance_requests (
  id INTEGER NOT NULL DEFAULT nextval('maintenance_requests_id_seq'::regclass),
  user_id INTEGER,
  society_id INTEGER,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(50),
  status VARCHAR(20) DEFAULT 'open'::character varying,
  priority VARCHAR(20) DEFAULT 'medium'::character varying,
  assigned_to INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  assigned_to_name VARCHAR(255),
  apartment_master_id INTEGER
);

CREATE TABLE marketplace_items (
  id INTEGER NOT NULL DEFAULT nextval('marketplace_items_id_seq'::regclass),
  user_id INTEGER,
  society_id INTEGER,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  price DECIMAL(10,2),
  category VARCHAR(50),
  condition VARCHAR(20),
  image_urls TEXT[],
  status VARCHAR(20) DEFAULT 'available'::character varying,
  is_blocked BOOLEAN DEFAULT false,
  blocked_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE notifications (
  id INTEGER NOT NULL DEFAULT nextval('notifications_id_seq'::regclass),
  sender_id INTEGER,
  society_id INTEGER,
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  notification_type VARCHAR(50) DEFAULT 'general'::character varying,
  target_roles TEXT[],
  is_emergency BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE parking_apartment_mapping (
  id INTEGER NOT NULL DEFAULT nextval('parking_apartment_mapping_id_seq'::regclass),
  parking_slot_id INTEGER,
  apartment_master_id INTEGER,
  mapped_by INTEGER,
  mapped_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE parking_rentals (
  id INTEGER NOT NULL DEFAULT nextval('parking_rentals_id_seq'::regclass),
  parking_slot_id INTEGER,
  owner_id INTEGER,
  tenant_id INTEGER,
  rental_start_date DATE DEFAULT CURRENT_DATE,
  rental_end_date DATE,
  monthly_rent DECIMAL(10,2),
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE parking_slots (
  id INTEGER NOT NULL DEFAULT nextval('parking_slots_id_seq'::regclass),
  society_id INTEGER,
  wing_id INTEGER,
  slot_number VARCHAR(20) NOT NULL,
  floor_number VARCHAR(50) NOT NULL,
  floor_prefix VARCHAR(20),
  is_available BOOLEAN DEFAULT true,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE payment_logs (
  id INTEGER NOT NULL DEFAULT nextval('payment_logs_id_seq'::regclass),
  bill_id INTEGER,
  user_id INTEGER,
  payment_gateway VARCHAR(50) NOT NULL DEFAULT 'internal'::character varying,
  gateway_order_id VARCHAR(255),
  gateway_payment_id VARCHAR(255),
  amount DECIMAL(10,2) NOT NULL,
  currency VARCHAR(3) DEFAULT 'INR'::character varying,
  status VARCHAR(50) NOT NULL,
  gateway_response JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE payment_receipts (
  id INTEGER NOT NULL DEFAULT nextval('payment_receipts_id_seq'::regclass),
  bill_id INTEGER,
  receipt_number VARCHAR(50) NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  payment_method VARCHAR(50) NOT NULL,
  transaction_id VARCHAR(255),
  generated_by INTEGER,
  society_id INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE petty_cash_transactions (
  id INTEGER NOT NULL DEFAULT nextval('petty_cash_transactions_id_seq'::regclass),
  society_id INTEGER,
  transaction_type VARCHAR(20),
  amount DECIMAL(10,2) NOT NULL,
  description TEXT NOT NULL,
  receipt_number VARCHAR(50),
  category VARCHAR(100),
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE poll_options (
  id INTEGER NOT NULL DEFAULT nextval('poll_options_id_seq'::regclass),
  post_id INTEGER,
  option_text VARCHAR(255) NOT NULL,
  vote_count INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE poll_votes (
  id INTEGER NOT NULL DEFAULT nextval('poll_votes_id_seq'::regclass),
  post_id INTEGER,
  user_id INTEGER,
  option_id INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE post_comments (
  id INTEGER NOT NULL DEFAULT nextval('post_comments_id_seq'::regclass),
  post_id INTEGER,
  user_id INTEGER,
  content TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE post_likes (
  id INTEGER NOT NULL DEFAULT nextval('post_likes_id_seq'::regclass),
  post_id INTEGER,
  user_id INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE purchase_order_items (
  id INTEGER NOT NULL DEFAULT nextval('purchase_order_items_id_seq'::regclass),
  purchase_order_id INTEGER,
  item_master_id INTEGER,
  quantity DECIMAL(10,2) NOT NULL,
  unit_price DECIMAL(10,2) NOT NULL,
  total_price DECIMAL(12,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE purchase_orders (
  id INTEGER NOT NULL DEFAULT nextval('purchase_orders_id_seq'::regclass),
  purchase_request_id INTEGER,
  vendor_id INTEGER,
  po_number VARCHAR(50),
  total_amount DECIMAL(12,2) NOT NULL,
  status VARCHAR(20) DEFAULT 'pending'::character varying,
  order_date DATE DEFAULT CURRENT_DATE,
  expected_delivery DATE,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE purchase_requests (
  id INTEGER NOT NULL DEFAULT nextval('purchase_requests_id_seq'::regclass),
  society_id INTEGER,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  category VARCHAR(100),
  estimated_amount DECIMAL(12,2),
  priority VARCHAR(20) DEFAULT 'medium'::character varying,
  status VARCHAR(20) DEFAULT 'pending'::character varying,
  requested_by INTEGER,
  approved_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE quotations (
  id INTEGER NOT NULL DEFAULT nextval('quotations_id_seq'::regclass),
  purchase_request_id INTEGER,
  vendor_id INTEGER,
  quotation_number VARCHAR(50),
  total_amount DECIMAL(12,2) NOT NULL,
  valid_until DATE,
  status VARCHAR(20) DEFAULT 'received'::character varying,
  quotation_file VARCHAR(500),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE service_providers (
  id INTEGER NOT NULL DEFAULT nextval('service_providers_id_seq'::regclass),
  society_id INTEGER,
  name VARCHAR(255) NOT NULL,
  service_type VARCHAR(50) NOT NULL,
  phone VARCHAR(20),
  email VARCHAR(255),
  rating DECIMAL(3,2) DEFAULT 0,
  description TEXT,
  availability TEXT,
  verified BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  user_id INTEGER
);

CREATE TABLE service_requests (
  id INTEGER NOT NULL DEFAULT nextval('service_requests_id_seq'::regclass),
  user_id INTEGER,
  society_id INTEGER,
  service_type VARCHAR(50) NOT NULL,
  description TEXT,
  status VARCHAR(20) DEFAULT 'open'::character varying,
  provider_id INTEGER,
  scheduled_date TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE social_posts (
  id INTEGER NOT NULL DEFAULT nextval('social_posts_id_seq'::regclass),
  user_id INTEGER,
  society_id INTEGER,
  content TEXT NOT NULL,
  image_url VARCHAR(500),
  post_type VARCHAR(20) DEFAULT 'post'::character varying,
  forum_topic VARCHAR(100),
  likes_count INTEGER DEFAULT 0,
  comments_count INTEGER DEFAULT 0,
  is_pinned BOOLEAN DEFAULT false,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE societies (
  id INTEGER NOT NULL DEFAULT nextval('societies_id_seq'::regclass),
  name VARCHAR(255) NOT NULL,
  address TEXT,
  city VARCHAR(100),
  state VARCHAR(100),
  pincode VARCHAR(10),
  is_active BOOLEAN DEFAULT true,
  fund_balance DECIMAL(12,2) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  email_otp_enabled BOOLEAN DEFAULT false,
  payment_gateway_mode VARCHAR(10) DEFAULT 'test'::character varying,
  razorpay_key_id VARCHAR(255),
  auto_approve_payments BOOLEAN DEFAULT false,
  require_payment_approval BOOLEAN DEFAULT true
);

CREATE TABLE society_expenses (
  id INTEGER NOT NULL DEFAULT nextval('society_expenses_id_seq'::regclass),
  society_id INTEGER,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  amount DECIMAL(10,2) NOT NULL,
  category VARCHAR(100),
  expense_date DATE DEFAULT CURRENT_DATE,
  added_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE system_settings (
  id INTEGER NOT NULL DEFAULT nextval('system_settings_id_seq'::regclass),
  setting_key VARCHAR(100) NOT NULL,
  setting_value TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tenants (
  id INTEGER NOT NULL DEFAULT nextval('tenants_id_seq'::regclass),
  apartment_id INTEGER,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  phone VARCHAR(20),
  age INTEGER,
  gender VARCHAR(10),
  occupation VARCHAR(100),
  emergency_contact_name VARCHAR(255),
  emergency_contact_phone VARCHAR(20),
  lease_start_date DATE,
  lease_end_date DATE,
  monthly_rent DECIMAL(10,2),
  security_deposit DECIMAL(10,2),
  status VARCHAR(20) DEFAULT 'pending'::character varying,
  admin_comments TEXT,
  approved_by INTEGER,
  approved_at TIMESTAMP,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_apartments (
  id INTEGER NOT NULL DEFAULT nextval('user_apartments_id_seq'::regclass),
  user_id INTEGER,
  society_id INTEGER,
  wing_id INTEGER,
  apartment_number VARCHAR(10) NOT NULL,
  is_primary BOOLEAN DEFAULT false,
  ownership_type VARCHAR(20) DEFAULT 'owner'::character varying,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  is_rented BOOLEAN DEFAULT false,
  status VARCHAR(20) DEFAULT 'approved'::character varying,
  apartment_master_id INTEGER
);

CREATE TABLE user_documents (
  id INTEGER NOT NULL DEFAULT nextval('user_documents_id_seq'::regclass),
  user_id INTEGER,
  society_id INTEGER,
  document_name VARCHAR(255) NOT NULL,
  document_type VARCHAR(50) NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  file_path VARCHAR(500) NOT NULL,
  file_size INTEGER NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE user_notifications (
  id INTEGER NOT NULL DEFAULT nextval('user_notifications_id_seq'::regclass),
  notification_id INTEGER,
  user_id INTEGER,
  is_read BOOLEAN DEFAULT false,
  read_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE users (
  id INTEGER NOT NULL DEFAULT nextval('users_id_seq'::regclass),
  email VARCHAR(255) NOT NULL,
  password VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  society_id INTEGER,
  wing_id INTEGER,
  apartment_number VARCHAR(10),
  role VARCHAR(20) DEFAULT 'owner'::character varying,
  is_active BOOLEAN DEFAULT true,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  is_verified BOOLEAN DEFAULT false,
  otp VARCHAR(6),
  otp_expires_at TIMESTAMP,
  admin_approved BOOLEAN DEFAULT false,
  approved_by INTEGER,
  approved_at TIMESTAMP,
  requires_password_change BOOLEAN DEFAULT false
);

CREATE TABLE vendors (
  id INTEGER NOT NULL DEFAULT nextval('vendors_id_seq'::regclass),
  society_id INTEGER,
  name VARCHAR(255) NOT NULL,
  contact_person VARCHAR(255),
  phone VARCHAR(20),
  email VARCHAR(255),
  address TEXT,
  services TEXT[],
  gst_number VARCHAR(50),
  pan_number VARCHAR(20),
  is_active BOOLEAN DEFAULT true,
  created_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE visitors (
  id INTEGER NOT NULL DEFAULT nextval('visitors_id_seq'::regclass),
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(20),
  purpose TEXT,
  society_id INTEGER,
  wing_id INTEGER,
  apartment_number VARCHAR(10),
  visitor_type VARCHAR(20) DEFAULT 'visitor'::character varying,
  status VARCHAR(20) DEFAULT 'pending'::character varying,
  entry_time TIMESTAMP,
  exit_time TIMESTAMP,
  otp VARCHAR(6),
  registered_by INTEGER,
  approved_by INTEGER,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  visitor_image VARCHAR(500),
  apartment_master_id INTEGER
);

CREATE TABLE wings (
  id INTEGER NOT NULL DEFAULT nextval('wings_id_seq'::regclass),
  society_id INTEGER,
  name VARCHAR(50) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

