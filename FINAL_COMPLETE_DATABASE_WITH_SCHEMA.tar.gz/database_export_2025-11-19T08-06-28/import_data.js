
const { Pool } = require('pg');
const fs = require('fs');
const { execSync } = require('child_process');

const pool = new Pool({
  host: 'localhost',
  port: 5432,
  database: 'society_management',
  user: 'postgres',
  password: 'your_password'
});

async function setupDatabase() {
  console.log('🏗️  Setting up database schema...');
  
  // Create database schema first
  const schema = fs.readFileSync('setup_database.sql', 'utf8');
  await pool.query(schema);
  
  console.log('✅ Database schema created');
}

async function importData() {
  console.log('📦 Starting data import...');
  
  const files = fs.readdirSync('.').filter(f => f.endsWith('_export.json'));
  let totalImported = 0;
  
  for (const file of files) {
    const data = JSON.parse(fs.readFileSync(file));
    
    if (data.rows.length === 0) {
      console.log(`⚪ ${data.table}: 0 rows (empty)`);
      continue;
    }
    
    console.log(`📥 Importing ${data.table}: ${data.rows.length} rows...`);
    
    for (const row of data.rows) {
      const columns = Object.keys(row);
      const values = Object.values(row);
      const placeholders = values.map((_, i) => `$${i + 1}`);
      
      const query = `INSERT INTO ${data.table} (${columns.join(', ')}) VALUES (${placeholders.join(', ')}) ON CONFLICT DO NOTHING`;
      
      try {
        await pool.query(query, values);
        totalImported++;
      } catch (err) {
        console.log(`❌ Error inserting into ${data.table}:`, err.message);
      }
    }
  }
  
  console.log(`\n🎉 Import completed! Total records: ${totalImported}`);
}

async function main() {
  try {
    await setupDatabase();
    await importData();
    
    console.log('\n✅ Database setup and import completed successfully!');
    console.log('\n📋 Next steps:');
    console.log('   1. Copy uploads/ directory to ../server/uploads/');
    console.log('   2. Update .env file with database credentials');
    console.log('   3. Start application: npm run dev');
    
  } catch (err) {
    console.error('❌ Error:', err.message);
  } finally {
    pool.end();
  }
}

main();
