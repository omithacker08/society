const { Pool } = require('pg');
const fs = require('fs');

const pool = new Pool({
  host: 'localhost',
  port: 5432,
  database: 'society_management_test',
  user: 'postgres',
  password: 'password'
});

async function quickTest() {
  try {
    // Test basic tables first
    console.log('🔧 Creating basic tables...');
    
    await pool.query(`
      CREATE TABLE IF NOT EXISTS societies (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS wings (
        id SERIAL PRIMARY KEY,
        society_id INTEGER REFERENCES societies(id),
        name VARCHAR(50) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
      
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        name VARCHAR(255) NOT NULL,
        society_id INTEGER REFERENCES societies(id),
        role VARCHAR(20) DEFAULT 'owner',
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);
    
    console.log('✅ Basic tables created');
    
    // Test import societies first
    const societiesData = JSON.parse(fs.readFileSync('societies_export.json'));
    console.log(`📥 Importing ${societiesData.count} societies...`);
    
    for (const row of societiesData.rows) {
      await pool.query(
        'INSERT INTO societies (id, name, created_at) VALUES ($1, $2, $3) ON CONFLICT DO NOTHING',
        [row.id, row.name, row.created_at]
      );
    }
    
    // Verify
    const result = await pool.query('SELECT COUNT(*) FROM societies');
    console.log(`✅ Societies imported: ${result.rows[0].count}`);
    
    console.log('🎉 Quick test successful!');
    
  } catch (err) {
    console.error('❌ Quick test failed:', err.message);
  } finally {
    pool.end();
  }
}

quickTest();