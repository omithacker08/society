const { Pool } = require('pg');
const fs = require('fs');

const pool = new Pool({
  host: 'localhost',
  port: 5432,
  database: 'society_management_test',
  user: 'postgres',
  password: 'password'
});

async function simpleImport() {
  try {
    // Just import societies first to test
    console.log('📦 Testing simple import...');
    
    await pool.query(`
      CREATE TABLE IF NOT EXISTS societies (
        id INTEGER PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        address TEXT,
        city VARCHAR(100),
        state VARCHAR(100),
        pincode VARCHAR(10),
        is_active BOOLEAN DEFAULT true,
        fund_balance DECIMAL(12,2) DEFAULT 0,
        email_otp_enabled BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    const data = JSON.parse(fs.readFileSync('societies_export.json'));
    console.log(`Found ${data.count} societies to import`);
    
    for (const row of data.rows) {
      await pool.query(
        'INSERT INTO societies VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) ON CONFLICT DO NOTHING',
        [row.id, row.name, row.address, row.city, row.state, row.pincode, row.is_active, row.fund_balance, row.email_otp_enabled, row.created_at]
      );
    }
    
    const result = await pool.query('SELECT COUNT(*) FROM societies');
    console.log(`✅ SUCCESS: ${result.rows[0].count} societies imported`);
    
  } catch (err) {
    console.error('❌ FAILED:', err.message);
  } finally {
    pool.end();
  }
}

simpleImport();