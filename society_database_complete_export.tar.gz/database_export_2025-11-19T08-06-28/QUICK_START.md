# Quick Start Guide

## 🚀 Simple Setup (3 Commands)

```bash
# 1. Extract
tar -xzf FINAL_COMPLETE_VERIFIED_EXPORT.tar.gz
cd database_export_2025-11-19T08-06-28/

# 2. Create & Import Database
createdb society_management
psql -d society_management -f setup_database.sql
psql -d society_management -f generated_inserts.sql

# 3. Copy Files & Start
cp -r uploads ../server/uploads/
cd .. && npm run dev
```

## 🔐 Default Login
- **Super Admin**: admin@test.com / password
- **Society Admin**: omithacker7@gmail.com / password
- **Owner**: amom08@gmail.com / password

## ✅ Verification
```sql
SELECT COUNT(*) FROM societies;      -- Should show: 2
SELECT COUNT(*) FROM users;          -- Should show: 14  
SELECT COUNT(*) FROM apartment_master; -- Should show: 811
```

## 🎯 What You Get
- **Complete database** with all relationships
- **2,051 records** across 55 tables
- **All uploaded files** and images
- **Ready-to-use** society management system

That's it! Your society platform is ready! 🏢✨