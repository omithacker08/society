const { Pool } = require('pg');
const fs = require('fs');

const pool = new Pool({
  host: 'localhost',
  port: 5432,
  database: 'society_management_test',
  user: 'postgres',
  password: 'password'
});

async function createAllTables() {
  const createQueries = [
    `CREATE TABLE IF NOT EXISTS societies (
      id SERIAL PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      address TEXT,
      city VARCHAR(100),
      state VARCHAR(100),
      pincode VARCHAR(10),
      is_active BOOLEAN DEFAULT true,
      fund_balance DECIMAL(12,2) DEFAULT 0,
      email_otp_enabled BOOLEAN DEFAULT false,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    
    `CREATE TABLE IF NOT EXISTS wings (
      id SERIAL PRIMARY KEY,
      society_id INTEGER REFERENCES societies(id),
      name VARCHAR(50) NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    
    `CREATE TABLE IF NOT EXISTS apartment_master (
      id SERIAL PRIMARY KEY,
      society_id INTEGER REFERENCES societies(id),
      wing_id INTEGER REFERENCES wings(id),
      apartment_number VARCHAR(10) NOT NULL,
      floor_number INTEGER,
      apartment_type VARCHAR(50),
      carpet_area DECIMAL(8,2),
      built_up_area DECIMAL(8,2),
      is_available BOOLEAN DEFAULT true,
      sale_deed_area DECIMAL(8,2),
      monthly_maintenance DECIMAL(8,2),
      possession_date DATE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    
    `CREATE TABLE IF NOT EXISTS users (
      id SERIAL PRIMARY KEY,
      email VARCHAR(255) UNIQUE NOT NULL,
      password VARCHAR(255) NOT NULL,
      name VARCHAR(255) NOT NULL,
      phone VARCHAR(20),
      society_id INTEGER REFERENCES societies(id),
      wing_id INTEGER REFERENCES wings(id),
      apartment_number VARCHAR(10),
      apartment_master_id INTEGER REFERENCES apartment_master(id),
      role VARCHAR(20) DEFAULT 'owner',
      is_active BOOLEAN DEFAULT true,
      is_verified BOOLEAN DEFAULT false,
      otp VARCHAR(6),
      otp_expires_at TIMESTAMP,
      last_login TIMESTAMP,
      created_by INTEGER REFERENCES users(id),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    
    `CREATE TABLE IF NOT EXISTS visitors (
      id SERIAL PRIMARY KEY,
      name VARCHAR(255) NOT NULL,
      phone VARCHAR(20),
      purpose TEXT,
      society_id INTEGER REFERENCES societies(id),
      wing_id INTEGER REFERENCES wings(id),
      apartment_number VARCHAR(10),
      apartment_master_id INTEGER REFERENCES apartment_master(id),
      visitor_type VARCHAR(20) DEFAULT 'visitor',
      status VARCHAR(20) DEFAULT 'pending',
      entry_time TIMESTAMP,
      exit_time TIMESTAMP,
      otp VARCHAR(6),
      image_url VARCHAR(500),
      vehicle_number VARCHAR(20),
      registered_by INTEGER REFERENCES users(id),
      approved_by INTEGER REFERENCES users(id),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    
    `CREATE TABLE IF NOT EXISTS social_posts (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id),
      society_id INTEGER REFERENCES societies(id),
      content TEXT NOT NULL,
      image_url VARCHAR(500),
      post_type VARCHAR(20) DEFAULT 'post',
      forum_topic VARCHAR(100),
      likes_count INTEGER DEFAULT 0,
      comments_count INTEGER DEFAULT 0,
      is_pinned BOOLEAN DEFAULT false,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    
    `CREATE TABLE IF NOT EXISTS notifications (
      id SERIAL PRIMARY KEY,
      sender_id INTEGER REFERENCES users(id),
      society_id INTEGER REFERENCES societies(id),
      title VARCHAR(255) NOT NULL,
      message TEXT NOT NULL,
      notification_type VARCHAR(50) DEFAULT 'general',
      target_roles TEXT[],
      is_emergency BOOLEAN DEFAULT false,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    
    `CREATE TABLE IF NOT EXISTS user_notifications (
      id SERIAL PRIMARY KEY,
      notification_id INTEGER REFERENCES notifications(id),
      user_id INTEGER REFERENCES users(id),
      is_read BOOLEAN DEFAULT false,
      read_at TIMESTAMP,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    
    `CREATE TABLE IF NOT EXISTS marketplace_items (
      id SERIAL PRIMARY KEY,
      user_id INTEGER REFERENCES users(id),
      society_id INTEGER REFERENCES societies(id),
      title VARCHAR(255) NOT NULL,
      description TEXT,
      price DECIMAL(10,2),
      category VARCHAR(50),
      condition VARCHAR(20),
      image_urls TEXT[],
      status VARCHAR(20) DEFAULT 'available',
      is_blocked BOOLEAN DEFAULT false,
      blocked_by INTEGER REFERENCES users(id),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    
    `CREATE TABLE IF NOT EXISTS parking_slots (
      id SERIAL PRIMARY KEY,
      society_id INTEGER REFERENCES societies(id),
      wing_id INTEGER REFERENCES wings(id),
      slot_number VARCHAR(20) NOT NULL,
      floor_number VARCHAR(10) NOT NULL,
      floor_prefix VARCHAR(10),
      is_available BOOLEAN DEFAULT true,
      created_by INTEGER REFERENCES users(id),
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`
  ];
  
  for (const query of createQueries) {
    await pool.query(query);
  }
  
  console.log('✅ All tables created');
}

async function importInOrder() {
  const importOrder = ['societies', 'wings', 'apartment_master', 'users', 'visitors', 'social_posts', 'notifications', 'user_notifications', 'marketplace_items', 'parking_slots'];
  
  let total = 0;
  
  for (const table of importOrder) {
    const file = `${table}_export.json`;
    if (!fs.existsSync(file)) continue;
    
    const data = JSON.parse(fs.readFileSync(file));
    if (data.rows.length === 0) continue;
    
    console.log(`📥 ${table}: ${data.rows.length} rows`);
    
    for (const row of data.rows) {
      const columns = Object.keys(row);
      const values = Object.values(row);
      const placeholders = values.map((_, i) => `$${i + 1}`);
      
      try {
        await pool.query(
          `INSERT INTO ${table} (${columns.join(', ')}) VALUES (${placeholders.join(', ')}) ON CONFLICT DO NOTHING`,
          values
        );
        total++;
      } catch (err) {
        console.log(`❌ ${table}:`, err.message);
      }
    }
  }
  
  console.log(`✅ Imported ${total} records`);
}

async function main() {
  try {
    await createAllTables();
    await importInOrder();
    console.log('🎉 Import successful!');
  } catch (err) {
    console.error('❌ Error:', err.message);
  } finally {
    pool.end();
  }
}

main();