-- Society Management Platform - Complete Data Import
-- Run this file to import all data into PostgreSQL

-- Schema will be created separately

-- Import data in correct order
-- Societies
INSERT INTO societies (id, name, address, city, state, pincode, is_active, fund_balance, email_otp_enabled, created_at) VALUES 
(1, 'Wadhwa Atmosphere', 'Mulund West, Mumbai', 'Mumbai', 'Maharashtra', '400080', true, 150000.00, true, '2024-01-01 00:00:00'),
(2, 'Test Society', 'Test Address', 'Test City', 'Test State', '123456', true, 0.00, false, '2024-01-01 00:00:00');

-- Wings
INSERT INTO wings (id, society_id, name, created_at) VALUES 
(1, 1, 'A', '2024-01-01 00:00:00'),
(2, 1, 'B', '2024-01-01 00:00:00'),
(3, 1, 'C', '2024-01-01 00:00:00'),
(4, 1, 'Security', '2024-01-01 00:00:00');

-- System Settings
INSERT INTO system_settings (id, setting_key, setting_value, description, created_at) VALUES 
(1, 'realtime_notifications', 'false', 'Enable WebSocket-based real-time notifications', '2024-01-01 00:00:00'),
(2, 'notification_poll_interval', '30', 'Polling interval in seconds for notifications', '2024-01-01 00:00:00'),
(3, 'max_file_upload_size', '10485760', 'Maximum file upload size in bytes (10MB)', '2024-01-01 00:00:00');

-- Users (sample data)
INSERT INTO users (id, email, password, name, phone, society_id, wing_id, apartment_number, role, is_active, is_verified, created_by, created_at) VALUES 
(1, 'admin@society.com', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Super Administrator', '9999999999', NULL, NULL, NULL, 'super_admin', true, true, NULL, '2024-01-01 00:00:00'),
(2, 'wadhwa.admin@society.com', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Wadhwa Admin', '9876543210', 1, 4, NULL, 'admin', true, true, 1, '2024-01-01 00:00:00'),
(3, 'reena@society.com', '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Reena Thacker', '9876543211', 1, 1, '101', 'owner', true, true, 2, '2024-01-01 00:00:00');

-- Sample facilities
INSERT INTO facilities (id, society_id, name, facility_type, max_booking_hours, operational_start, operational_end, is_available, created_at) VALUES 
(1, 1, 'Community Hall', 'multipurpose_hall', 4, '06:00', '22:00', true, '2024-01-01 00:00:00'),
(2, 1, 'Badminton Court 1', 'badminton_court', 2, '06:00', '22:00', true, '2024-01-01 00:00:00'),
(3, 1, 'Swimming Pool', 'swimming_pool', 2, '06:00', '22:00', true, '2024-01-01 00:00:00'),
(4, 1, 'Gym', 'gym', 2, '06:00', '22:00', true, '2024-01-01 00:00:00');

-- Sample service providers
INSERT INTO service_providers (id, society_id, name, service_type, phone, email, verified, is_active, created_by, created_at) VALUES 
(1, 1, 'Quick Fix Electricians', 'electricity', '9876543230', 'quickfix@email.com', true, true, 2, '2024-01-01 00:00:00'),
(2, 1, 'Plumb Pro Services', 'plumbing', '9876543231', 'plumbpro@email.com', true, true, 2, '2024-01-01 00:00:00'),
(3, 1, 'AC Care Experts', 'ac_repair', '9876543232', 'accare@email.com', true, true, 2, '2024-01-01 00:00:00');

-- Sample social post
INSERT INTO social_posts (id, user_id, society_id, content, post_type, is_pinned, created_at) VALUES 
(1, 2, 1, 'Welcome to Wadhwa Atmosphere! Please follow society guidelines and maintain cleanliness.', 'announcement', true, '2024-01-01 00:00:00');

-- Sample notification
INSERT INTO notifications (id, sender_id, society_id, title, message, notification_type, target_roles, is_emergency, created_at) VALUES 
(1, 2, 1, 'Welcome to Digital Society Management', 'Your society is now digitally enabled! Explore all features and stay connected.', 'announcement', ARRAY['owner', 'tenant'], false, '2024-01-01 00:00:00');

-- Fix sequences
SELECT setval('societies_id_seq', (SELECT MAX(id) FROM societies));
SELECT setval('wings_id_seq', (SELECT MAX(id) FROM wings));
SELECT setval('users_id_seq', (SELECT MAX(id) FROM users));
SELECT setval('facilities_id_seq', (SELECT MAX(id) FROM facilities));
SELECT setval('service_providers_id_seq', (SELECT MAX(id) FROM service_providers));
SELECT setval('social_posts_id_seq', (SELECT MAX(id) FROM social_posts));
SELECT setval('notifications_id_seq', (SELECT MAX(id) FROM notifications));
SELECT setval('system_settings_id_seq', (SELECT MAX(id) FROM system_settings));

-- Verify import
SELECT 'Import completed successfully!' as status;
SELECT 
    'societies' as table_name, COUNT(*) as record_count FROM societies
UNION ALL SELECT 'users', COUNT(*) FROM users
UNION ALL SELECT 'facilities', COUNT(*) FROM facilities
UNION ALL SELECT 'service_providers', COUNT(*) FROM service_providers
ORDER BY table_name;