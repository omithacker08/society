# Simple SQL-Only Setup

## Files Included
- `setup_database.sql` - Creates all tables and schema
- `import_all_data.sql` - Sample data for testing
- `generated_inserts.sql` - All your actual data as SQL
- `uploads/` - All uploaded files

## Setup Instructions

### 1. Create Database
```bash
createdb society_management
```

### 2. Import Schema
```bash
psql -d society_management -f setup_database.sql
```

### 3. Import Data (Choose One)

**Option A: Sample Data (for testing)**
```bash
psql -d society_management_new -f import_all_data.sql
```

**Option B: Your Actual Data**
```bash
psql -d society_management -f generated_inserts.sql
```

### 4. Copy Files
```bash
cp -r uploads ../server/uploads
```

### 5. Update .env
```
DB_NAME=society_management
DB_USER=postgres
DB_PASSWORD=your_password
```

## Default Login (Sample Data)
- **Super Admin**: admin@society.com / admin123
- **Society Admin**: wadhwa.admin@society.com / admin123  
- **Owner**: reena@society.com / admin123

## Verification
```sql
-- Check tables
\dt

-- Check data
SELECT COUNT(*) FROM societies;
SELECT COUNT(*) FROM users;
```

No JavaScript required - pure SQL setup!