const { Pool } = require('pg');
const fs = require('fs');

const pool = new Pool({
  host: 'localhost',
  port: 5432,
  database: 'society_management_test',
  user: 'postgres',
  password: 'password'
});

async function setupDatabase() {
  console.log('🏗️  Setting up test database schema...');
  
  const schema = fs.readFileSync('setup_database.sql', 'utf8');
  await pool.query(schema);
  
  console.log('✅ Test database schema created');
}

async function importData() {
  console.log('📦 Starting test data import...');
  
  const importOrder = [
    'societies', 'wings', 'apartment_master', 'users', 'user_apartments',
    'visitors', 'entry_passes', 'maintenance_requests', 'social_posts',
    'notifications', 'user_notifications', 'marketplace_items',
    'service_providers', 'service_requests', 'facilities', 'facility_bookings',
    'maids', 'maid_assignments', 'maid_attendance', 'maid_reviews',
    'chats', 'chat_messages', 'post_likes', 'post_comments',
    'parking_slots', 'parking_apartment_mapping', 'parking_rentals',
    'system_settings', 'family_members', 'user_documents'
  ];
  
  let totalImported = 0;
  
  for (const tableName of importOrder) {
    const file = `${tableName}_export.json`;
    
    if (!fs.existsSync(file)) continue;
    
    const data = JSON.parse(fs.readFileSync(file));
    
    if (data.rows.length === 0) {
      console.log(`⚪ ${data.table}: 0 rows (empty)`);
      continue;
    }
    
    console.log(`📥 Importing ${data.table}: ${data.rows.length} rows...`);
    
    for (const row of data.rows) {
      const columns = Object.keys(row);
      const values = Object.values(row);
      const placeholders = values.map((_, i) => `$${i + 1}`);
      
      const query = `INSERT INTO ${data.table} (${columns.join(', ')}) VALUES (${placeholders.join(', ')}) ON CONFLICT DO NOTHING`;
      
      try {
        await pool.query(query, values);
        totalImported++;
      } catch (err) {
        console.log(`❌ Error inserting into ${data.table}:`, err.message);
      }
    }
  }
  
  console.log(`\n🎉 Test import completed! Total records: ${totalImported}`);
  return totalImported;
}

async function verifyImport() {
  console.log('🔍 Verifying import...');
  
  const result = await pool.query(`
    SELECT 
      schemaname,
      tablename,
      n_live_tup as row_count
    FROM pg_stat_user_tables 
    WHERE n_live_tup > 0
    ORDER BY n_live_tup DESC
  `);
  
  console.log('\n📊 Tables with data:');
  result.rows.forEach(row => {
    console.log(`   ✅ ${row.tablename}: ${row.row_count} rows`);
  });
  
  return result.rows.length;
}

async function testImport() {
  try {
    await pool.query('SET session_replication_role = replica;');
    
    await setupDatabase();
    const imported = await importData();
    const tablesWithData = await verifyImport();
    
    await pool.query('SET session_replication_role = DEFAULT;');
    
    console.log('\n✅ TEST RESULTS:');
    console.log(`   Records imported: ${imported}`);
    console.log(`   Tables with data: ${tablesWithData}`);
    console.log('   Status: SUCCESS');
    
  } catch (err) {
    console.error('❌ TEST FAILED:', err.message);
  } finally {
    pool.end();
  }
}

testImport();