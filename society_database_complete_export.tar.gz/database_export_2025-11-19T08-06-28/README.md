# Society Management Database Export

## Contents
- **55 JSON files** - All table data (2,051 total records)
- **setup_database.sql** - Complete database schema creation script
- **complete_schema.sql** - Generated schema from actual database
- **import_data.js** - Automated import script with schema setup
- **uploads/** - All uploaded files and images

## Quick Setup

### 1. Create Database
```bash
createdb society_management
```

### 2. Import Everything
```bash
# Install dependencies
npm install pg

# Run import (creates tables + imports data)
node import_data.js
```

### 3. Setup Files
```bash
# Copy uploads to application
cp -r uploads ../server/uploads

# Update database credentials in .env
```

### 4. Start Application
```bash
cd ..
npm run dev
```

## Manual Setup (Alternative)

### Option 1: Schema + Data
```bash
# Create schema first
psql -d society_management -f setup_database.sql

# Then import data
node import_data.js
```

### Option 2: Individual Tables
```bash
# Create database
createdb society_management

# Import each JSON file manually using custom script
```

## What's Included

### Core Data
- **2 societies** with complete configuration
- **14 users** across all roles (super_admin, admin, owner, builder, service_provider)
- **811 apartments** with full details
- **1000 parking slots** with mappings

### Features Data
- **5 visitors** with approval history
- **17 social posts** with likes and comments
- **20 marketplace items** with images
- **33 notifications** system-wide
- **4 facilities** with booking system
- **4 maids** with assignments and reviews
- **Chat system** with messages
- **Financial records** and transactions

### System Configuration
- **System settings** for application behavior
- **User permissions** and role-based access
- **File uploads** directory structure
- **Database indexes** for performance

## Default Login Credentials

| Role | Email | Password |
|------|-------|----------|
| Super Admin | admin@society.com | admin123 |
| Society Admin | wadhwa.admin@society.com | admin123 |
| Owner | reena@society.com | admin123 |
| Builder | builder@society.com | admin123 |

⚠️ **Change all passwords after setup!**

## Troubleshooting

### Database Connection Issues
- Ensure PostgreSQL is running
- Check credentials in import_data.js
- Verify database exists

### Import Errors
- Check PostgreSQL version (15+ recommended)
- Ensure sufficient disk space
- Review error messages for specific issues

### File Upload Issues
- Verify uploads directory permissions: `chmod -R 755 uploads`
- Check file paths in database match actual files
- Ensure web server can access uploads directory

## Support
This export contains your complete society management system. All tables, data, and files are included for seamless migration to any new system.